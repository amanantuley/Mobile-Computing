package com.example.databaseapp

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface studentDao {

    @Insert
    suspend fun insert(student: student)

    @Delete
    suspend fun delete(student: student)

    @Query("SELECT * FROM student")
    fun getAllStudents(): Flow<List<student>>
}