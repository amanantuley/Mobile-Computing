package com.example.databaseapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student")
data class student(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val course: String
)