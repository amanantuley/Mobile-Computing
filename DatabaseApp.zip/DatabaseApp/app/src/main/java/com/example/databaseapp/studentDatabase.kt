package com.example.databaseapp

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [student::class], version = 1)
abstract class studentDatabase : RoomDatabase() {

    abstract fun studentDao(): studentDao

    companion object {
        @Volatile
        private var INSTANCE: studentDatabase? = null

        fun getDatabase(context: Context): studentDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    studentDatabase::class.java,
                    "student_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}