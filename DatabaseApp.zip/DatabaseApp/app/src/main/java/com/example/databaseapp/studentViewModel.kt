package com.example.databaseapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class studentViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = studentDatabase
        .getDatabase(application)
        .studentDao()

    val students: Flow<List<student>> = dao.getAllStudents()

    fun addStudent(name: String, course: String) {
        viewModelScope.launch {
            dao.insert(student(name = name, course = course))
        }
    }

    fun deleteStudent(student: student) {
        viewModelScope.launch {
            dao.delete(student)
        }
    }
}