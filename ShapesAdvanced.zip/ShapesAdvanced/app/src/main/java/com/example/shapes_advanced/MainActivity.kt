package com.example.shapes_advanced

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                ShapeDrawingApp()
            }
        }
    }
}

@Composable
fun ShapeDrawingApp() {

    var shapeName by remember { mutableStateOf("") }
    var drawShape by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "Graphical Primitives Drawer",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = shapeName,
            onValueChange = { shapeName = it.lowercase() },
            label = { Text("Enter shape name") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { drawShape = shapeName },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Draw Shape")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
        ) {

            when (drawShape) {

                "circle" -> {
                    drawCircle(
                        color = Color.Red,
                        radius = size.minDimension / 4,
                        center = center
                    )
                }

                "rectangle" -> {
                    drawRect(
                        color = Color.Blue,
                        size = Size(300f, 180f),
                        topLeft = Offset(100f, 80f)
                    )
                }

                "square" -> {
                    drawRect(
                        color = Color.Green,
                        size = Size(200f, 200f),
                        topLeft = Offset(120f, 60f)
                    )
                }

                "line" -> {
                    drawLine(
                        color = Color.Black,
                        start = Offset(100f, 100f),
                        end = Offset(500f, 300f),
                        strokeWidth = 8f
                    )
                }

                "oval" -> {
                    drawOval(
                        color = Color.Magenta,
                        topLeft = Offset(120f, 100f),
                        size = Size(300f, 180f)
                    )
                }

                "triangle" -> {
                    val path = Path().apply {
                        moveTo(300f, 80f)
                        lineTo(100f, 350f)
                        lineTo(500f, 350f)
                        close()
                    }
                    drawPath(path, Color.Cyan)
                }

                "diamond" -> {
                    val path = Path().apply {
                        moveTo(300f, 60f)
                        lineTo(500f, 200f)
                        lineTo(300f, 340f)
                        lineTo(100f, 200f)
                        close()
                    }
                    drawPath(path, Color.Yellow)
                }

                "arc" -> {
                    drawArc(
                        color = Color.DarkGray,
                        startAngle = 0f,
                        sweepAngle = 270f,
                        useCenter = false,
                        topLeft = Offset(150f, 100f),
                        size = Size(300f, 300f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 10f)
                    )
                }

                "star" -> {
                    val path = Path().apply {
                        moveTo(300f, 80f)
                        lineTo(350f, 200f)
                        lineTo(500f, 200f)
                        lineTo(380f, 280f)
                        lineTo(430f, 400f)
                        lineTo(300f, 320f)
                        lineTo(170f, 400f)
                        lineTo(220f, 280f)
                        lineTo(100f, 200f)
                        lineTo(250f, 200f)
                        close()
                    }
                    drawPath(path, Color.Red)
                }

                "heart" -> {
                    val path = Path().apply {
                        moveTo(300f, 380f)
                        cubicTo(100f, 200f, 150f, 60f, 300f, 160f)
                        cubicTo(450f, 60f, 500f, 200f, 300f, 380f)
                    }
                    drawPath(path, Color.Red)
                }
            }
        }
    }
}