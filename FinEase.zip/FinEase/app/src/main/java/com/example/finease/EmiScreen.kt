package com.example.finease

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.pow

@Composable
fun EmiScreen(onBack: () -> Unit) {

    var loan by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var tenure by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text("Loan EMI Calculator", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = loan,
            onValueChange = { loan = it },
            label = { Text("Loan Amount") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = rate,
            onValueChange = { rate = it },
            label = { Text("Interest Rate (%)") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = tenure,
            onValueChange = { tenure = it },
            label = { Text("Tenure (Months)") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val p = loan.toDoubleOrNull()
                val r = rate.toDoubleOrNull()
                val n = tenure.toIntOrNull()

                if (p != null && r != null && n != null) {
                    val monthlyRate = r / 12 / 100
                    val emi = (p * monthlyRate * (1 + monthlyRate).pow(n)) /
                            ((1 + monthlyRate).pow(n) - 1)

                    result = "Monthly EMI: ₹ %.2f".format(emi)
                } else {
                    result = "Enter valid inputs"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Calculate EMI")
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(result)

        Spacer(modifier = Modifier.height(24.dp))
        OutlinedButton(onClick = onBack) {
            Text("Back")
        }
    }
}