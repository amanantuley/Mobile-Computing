package com.example.finease

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TaxScreen(onBack: () -> Unit) {

    var income by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text("Income Tax Calculator", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = income,
            onValueChange = { income = it },
            label = { Text("Annual Income") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val inc = income.toDoubleOrNull()
                if (inc != null) {
                    val tax = when {
                        inc <= 250000 -> 0.0
                        inc <= 500000 -> (inc - 250000) * 0.05
                        inc <= 1000000 -> 12500 + (inc - 500000) * 0.20
                        else -> 112500 + (inc - 1000000) * 0.30
                    }
                    result = "Tax Payable: ₹ %.2f".format(tax)
                } else {
                    result = "Please enter valid income"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Calculate Tax")
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(result)

        Spacer(modifier = Modifier.height(24.dp))
        OutlinedButton(onClick = onBack) {
            Text("Back")
        }
    }
}