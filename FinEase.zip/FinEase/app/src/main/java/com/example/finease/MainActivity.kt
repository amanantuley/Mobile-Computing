package com.example.finease

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.finease.ui.theme.FinEaseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            FinEaseTheme {
                var screen by remember { mutableStateOf("HOME") }

                when (screen) {
                    "HOME" -> HomeScreen(
                        onTaxClick = { screen = "TAX" },
                        onEmiClick = { screen = "EMI" }
                    )
                    "TAX" -> TaxScreen { screen = "HOME" }
                    "EMI" -> EmiScreen { screen = "HOME" }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onTaxClick: () -> Unit, onEmiClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("FinEase", style = MaterialTheme.typography.headlineLarge)
        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = onTaxClick, modifier = Modifier.fillMaxWidth()) {
            Text("Income Tax Calculator")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onEmiClick, modifier = Modifier.fillMaxWidth()) {
            Text("Loan EMI Calculator")
        }
    }
}